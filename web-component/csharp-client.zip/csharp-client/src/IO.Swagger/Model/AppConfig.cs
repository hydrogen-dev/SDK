namespace IO.Swagger.Model
{
    public class AppConfig
    {
        public string appName { get; set; }
        public string authType { get; set; }
    }
}