namespace IO.Swagger.Model
{
    public class TagAttributes
    {
        public string name { get; set; }
        public string value { get; set; }
    }
}